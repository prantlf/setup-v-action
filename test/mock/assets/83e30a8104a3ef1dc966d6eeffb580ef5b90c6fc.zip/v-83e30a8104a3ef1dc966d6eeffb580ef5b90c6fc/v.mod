Module {
	name: 'V'
	version: '0.0.0'
}
